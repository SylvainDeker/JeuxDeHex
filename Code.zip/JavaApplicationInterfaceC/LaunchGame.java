import java.io.IOException;

/**
 * Created by salimcherifi on 5/18/17.
 */
public class LaunchGame {
    public static void main(String args[]) throws IOException, InterruptedException {
        Game game = new Game();
        game.menuGame();
    }
}
