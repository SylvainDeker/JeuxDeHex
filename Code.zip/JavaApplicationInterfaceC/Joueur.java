/**
 * Created by salimcherifi on 5/17/17.
 */
public class Joueur {
    private String name;

    public Joueur(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
