package Heritage;

/**
 * Created by salimcherifi on 10/02/17.
 */
public class Dragon extends EtreVivant {
    public Dragon(String nom) {
        super(200, nom);
    }
}
