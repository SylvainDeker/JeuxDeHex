package Heritage;


/**
 * Created by salimcherifi on 10/02/17.
 */
public class Heros extends Homme {
    public Heros(String nom) {
        super(nom);
        this.qteVie = 150;
    }

}
