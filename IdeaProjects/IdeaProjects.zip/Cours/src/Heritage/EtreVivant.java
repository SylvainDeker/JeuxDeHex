package Heritage;

/**
 * Created by salimcherifi on 10/02/17.
 */
public class EtreVivant {
    public int qteVie;
    private String nom;

    public EtreVivant(int qteVie, String nom) {
        this.qteVie = qteVie;
        this.nom = nom;
    }
}
