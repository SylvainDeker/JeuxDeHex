package CollectionArrayList;

/**
 * Created by salimcherifi on 03/03/17.
 */
public interface IfileBornee extends Ifile {
    public boolean estPleine();
}
