package CollectionArrayList;

/**
 * Created by salimcherifi on 24/02/17.
 */
public interface Ifile {
    public void inserer(int i);
    public void supprimer();
    public boolean estVide();
    public int premier();
    public int longueur();

}
