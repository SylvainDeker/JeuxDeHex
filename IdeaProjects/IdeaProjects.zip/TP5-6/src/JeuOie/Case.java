package JeuOie;

/**
 * Created by salimcherifi on 27/02/17.
 */
public class Case {
    protected int numCase;

    public Case(int numCase) {
        this.numCase = numCase;
    }

    public String getNom(){
        return(" numero "+this.numCase);
    }

    private Case arrivee(Oie oie){

    }

    public Case depart(Oie oie){
        return oie.
    }

    private Case caseSuivante(Oie oie, int numCaseDestination){
        return oie.
    }
}
