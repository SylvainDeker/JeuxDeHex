package JeuOie;

/**
 * Created by salimcherifi on 27/02/17.
 */
public class Plateau {

    private int NB_CASES = 63;
    private Case cases[];


    public Plateau() {
        this.cases = new Case[this.NB_CASES];
        for (int i = 0;i < this.NB_CASES; i++){
            this.cases[i] = new Case(i);
        }
    }

    public Case caseDebutPartie(){
        return this.cases[0];
    }
}
