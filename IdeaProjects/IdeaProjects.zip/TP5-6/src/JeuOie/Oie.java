package JeuOie;

/**
 * Permet de créer une oie
 */
public class Oie {
    private String couleur;
    private Plateau plateau;
    private Des des;
    private Journal journal;
    private Case casePlateau;

    public Oie(String couleur, Plateau plateau, Des des){
        this.couleur = couleur;
        this.plateau = plateau;
        this.des = des;
    }

    public String getCouleur() {
        return couleur;
    }

    public Plateau getPlateau() {
        return plateau;
    }

    public int lanceDe(){
        return this.des.lancer();
    }

    public void ajouterMessage(String message){
        this.journal.ajouterMessage(message);
    }

    public boolean action(){
        return true;
    }
}

