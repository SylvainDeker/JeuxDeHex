package JeuOie;

import java.util.Random;

/**
 * Permet de créer les deux dés
 */
public class Des {
    /**
     * Lancer les dés
     * @return le nombre affichés par les deux dés
     */
    public int lancer(){
        Random rnd = new Random();
        int v = rnd.nextInt(12);
        return v;
    }
}
