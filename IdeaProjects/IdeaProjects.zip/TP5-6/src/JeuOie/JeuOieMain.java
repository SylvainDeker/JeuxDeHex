package JeuOie;

/**
 * Created by salimcherifi on 27/02/17.
 */
public class JeuOieMain {
    public static void main(String argv[]){
        JeuOie jeuOie = new JeuOie(3);
        jeuOie.ajouterOie("verte");
        jeuOie.ajouterOie("jaune");
        jeuOie.ajouterOie("bleu");
        jeuOie.jouer();
    }
}
