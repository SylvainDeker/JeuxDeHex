package JeuOie;

/**
 * Created by salimcherifi on 27/02/17.
 */
public class Journal {
    private String message;

    public void ajouterMessage(String message){
        this.message.concat(message);
    }

    public void afficherMessage(){
        System.out.println(this.message);
    }
}
