package JeuOie;

/**
 * Created by salimcherifi on 14/03/17.
 */
public class CasePrison extends Case {

    private Oie oieCoince;
    public CasePrison() {
        super(51);
    }

    @Override
    protected Case arrivee(Oie oie) {
        if (oieCoince != null){
            oieCoince.ajouterMessage("L'oie "+oieCoince.getCouleur()+" est libre ! ");
        }

        this.oieCoince = oie;
        oie.ajouterMessage(" tombe sur la case prison et reste bloqué ou libère une oie! ");

        return this;

    }

    @Override
    public Case depart(Oie oie){
        if(this.oieCoince != null){
            if(!oie.equals(this.oieCoince)){

                String couleur = oie.getCouleur();
                this.oieCoince = null;
                String nomCase = getNom();
                oie.ajouterMessage("L'oie "+couleur+" est sur la case "+nomCase);
                int valeurDes = oie.lanceDe();

                Case caseArrivee = this.caseSuivante(oie, valeurDes+this.numCase-1);
                return caseArrivee;




            }else{

                oie.ajouterMessage("L'oie "+oieCoince.getCouleur()+" reste en prison ");
                return oie.getPlateau().donnerCase(51);
            }
        }else{
            String couleur = oie.getCouleur();
            String nomCase = getNom();
            oie.ajouterMessage("L'oie "+couleur+" est sur la case "+nomCase);
            int valeurDes = oie.lanceDe();

            Case caseArrivee = this.caseSuivante(oie, valeurDes+this.numCase-1);
            return caseArrivee;
        }




    }


}
