package JeuOie;

/**
 * Created by salimcherifi on 27/02/17.
 */
public class Case {
    protected int numCase;

    public Case(int numCase) {
        this.numCase = numCase+1;
    }

    public String getNom(){
        return("numero "+this.numCase);
    }

    protected Case arrivee(Oie oie){
        String nomCase = getNom();
        oie.ajouterMessage(" elle va sur la case "+ nomCase);
        return this;
    }

    public Case depart(Oie oie){
        String couleur = oie.getCouleur();
        String nomCase = getNom();
        oie.ajouterMessage("L'oie "+couleur+" est sur la case "+nomCase);
        int valeurDes = oie.lanceDe();

        Case caseArrivee = this.caseSuivante(oie, valeurDes+this.numCase-1);
        return caseArrivee;


    }

    protected Case caseSuivante(Oie oie, int numCaseDestination){
        Case caseDestination = oie.getPlateau().donnerCase(numCaseDestination);
        Case caseArrivee = caseDestination.arrivee(oie);
        return caseArrivee;

    }
}
