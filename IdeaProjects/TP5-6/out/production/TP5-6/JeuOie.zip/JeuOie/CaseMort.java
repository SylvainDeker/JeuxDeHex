package JeuOie;

/**
 * Created by salimcherifi on 14/03/17.
 */
public class CaseMort extends Case {
    public CaseMort() {
        super(57);
    }
    @Override
    protected Case arrivee(Oie oie){
        String nomCase = getNom();
        oie.ajouterMessage(" tombe sur la case mort et reviens à la case numéro 1 ");
        return oie.getPlateau().donnerCase(0);
    }
}
