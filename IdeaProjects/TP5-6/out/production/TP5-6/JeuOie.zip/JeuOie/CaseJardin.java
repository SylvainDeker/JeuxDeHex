package JeuOie;

/**
 * Created by salimcherifi on 14/03/17.
 */
public class CaseJardin extends Case {
    public CaseJardin() {
        super(62);
    }
    @Override
    protected Case arrivee(Oie oie){
        String nomCase = getNom();
        oie.ajouterMessage(" arrive au jardin et gagne ! ");
        return null;
    }
}
