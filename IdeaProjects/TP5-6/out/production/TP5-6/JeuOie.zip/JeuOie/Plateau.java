package JeuOie;

/**
 * Created by salimcherifi on 27/02/17.
 */
public class Plateau {

    private int NB_CASES = 63;
    private Case cases[];


    public Plateau() {
        this.cases = new Case[this.NB_CASES];
        for (int i = 0;i < this.NB_CASES; i++){
            this.cases[i] = new Case(i);
        }
        initialisationCasesSpecifique();
    }


    private void initialisationCasesSpecifique(){
        for (int i=0;i < this.NB_CASES;i=i+9){
            this.cases[i] = new CasesFastes(i);
        }
        this.cases[5] = new CasePont();
//        this.cases[18] = new CaseHotel(i);
//        this.cases[30] = new CasePuits(i);
        this.cases[41] = new CaseLabyrinthe();
        this.cases[51] = new CasePrison();
        this.cases[57] = new CaseMort();
        this.cases[62] = new CaseJardin();

    }

    public Case caseDebutPartie(){
        return this.cases[0];
    }

    public Case donnerCase(int i){
        if(i > 62){
            return this.cases[62-(i%62)];
        }
        return this.cases[i];
    }
}
