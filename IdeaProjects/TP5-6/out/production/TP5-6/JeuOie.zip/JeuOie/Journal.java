package JeuOie;

/**
 * Created by salimcherifi on 27/02/17.
 */
public class Journal {
    private String message = "";

    public void ajouterMessage(String message){
        this.message = this.message + message;
    }

    public void afficherMessage(){
        System.out.println(this.message);
        message = "";
    }
}
