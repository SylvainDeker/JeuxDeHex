package JeuOie;

/**
 * Created by salimcherifi on 14/03/17.
 */
public class CasePont extends Case {
    public CasePont() {
        super(5);
    }
    @Override
    protected Case arrivee(Oie oie){
        String nomCase = getNom();
        oie.ajouterMessage(" tombe sur la case pont et elle va sur la case numero 12 ");
        return oie.getPlateau().donnerCase(11);
    }
}
