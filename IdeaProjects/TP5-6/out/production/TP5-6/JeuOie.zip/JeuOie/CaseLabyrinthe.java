package JeuOie;

/**
 * Created by salimcherifi on 14/03/17.
 */
public class CaseLabyrinthe extends Case {
    public CaseLabyrinthe() {
        super(41);
    }
    @Override
    protected Case arrivee(Oie oie){
        String nomCase = getNom();
        oie.ajouterMessage(" tombe sur le labyrinthe et va sur la case 30 ");
        return oie.getPlateau().donnerCase(29);
    }
}
