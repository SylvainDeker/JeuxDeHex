package JeuOie;

/**
 * Created by salimcherifi on 14/03/17.
 */
public class CasesFastes extends Case {
    public CasesFastes(int numCase) {
        super(numCase);
    }

    protected Case arrivee(Oie oie){
        String nomCase = getNom();
        oie.ajouterMessage(" tombe sur une case fast et rejoue ! ");
        int valeurDes = oie.lanceDe();
        return this.caseSuivante(oie,valeurDes+this.numCase-1);

    }
}
